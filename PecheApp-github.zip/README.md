# PêcheApp

Application Android pour les pêcheurs : comptes, poissons préférés, spots, météo, réglementation.

## Récupérer l'application (sans rien installer sur le PC)

1. Mets ces fichiers sur GitHub (dépôt public ou privé).
2. Va dans l'onglet **Actions** du dépôt : l'APK se construit tout seul (5 à 10 minutes).
3. Clique sur la dernière exécution, puis télécharge **PecheApp-apk** en bas de page.
4. Dézippe, copie `app-debug.apk` sur ton téléphone et installe-le.

Pour relancer une construction à la main : Actions > Construire l'APK > Run workflow.
