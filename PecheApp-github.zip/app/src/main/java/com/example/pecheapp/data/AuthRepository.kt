package com.example.pecheapp.data

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Comptes 100 % locaux (aucun serveur). Les mots de passe sont hachés (PBKDF2 + sel).
 * Cette classe pourra être remplacée plus tard par Firebase sans toucher à l'interface.
 */
class AuthRepository(context: Context) {
    private val prefs = context.getSharedPreferences("peche_auth", Context.MODE_PRIVATE)

    var currentUser: String?
        get() = prefs.getString("session", null)
        private set(value) {
            prefs.edit().apply { if (value == null) remove("session") else putString("session", value) }.apply()
        }

    private fun users() = JSONObject(prefs.getString("users", "{}") ?: "{}")
    private fun saveUsers(o: JSONObject) = prefs.edit().putString("users", o.toString()).apply()

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** Retourne un message d'erreur, ou null si tout s'est bien passé. */
    fun register(username: String, password: String): String? {
        val id = username.trim().lowercase()
        if (id.length < 3) return "L'identifiant doit contenir au moins 3 caractères."
        if (password.length < 6) return "Le mot de passe doit contenir au moins 6 caractères."
        val all = users()
        if (all.has(id)) return "Cet identifiant existe déjà."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        all.put(
            id,
            JSONObject()
                .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .put("hash", hash(password, salt))
                .put("fish", JSONArray())
        )
        saveUsers(all)
        currentUser = id
        return null
    }

    fun login(username: String, password: String): String? {
        val id = username.trim().lowercase()
        val u = users().optJSONObject(id) ?: return "Identifiant ou mot de passe incorrect."
        val salt = Base64.decode(u.getString("salt"), Base64.NO_WRAP)
        if (hash(password, salt) != u.getString("hash")) return "Identifiant ou mot de passe incorrect."
        currentUser = id
        return null
    }

    fun logout() { currentUser = null }

    fun favoriteFish(): Set<String> {
        val id = currentUser ?: return emptySet()
        val arr = users().optJSONObject(id)?.optJSONArray("fish") ?: return emptySet()
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    fun saveFavoriteFish(fish: Set<String>) {
        val id = currentUser ?: return
        val all = users()
        val u = all.optJSONObject(id) ?: return
        u.put("fish", JSONArray(fish.toList()))
        saveUsers(all)
    }
}
