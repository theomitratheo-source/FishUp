package com.example.pecheapp.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Teal = Color(0xFF4FD1C5)
val Navy = Color(0xFF0A1929)
val NavyLight = Color(0xFF102A43)

val OceanBrush = Brush.verticalGradient(listOf(Color(0xFF0D3B5C), Navy))

private val Colors = darkColorScheme(
    primary = Teal,
    onPrimary = Color(0xFF00201D),
    secondary = Color(0xFF63B3ED),
    background = Navy,
    onBackground = Color(0xFFE6F1FA),
    surface = NavyLight,
    onSurface = Color(0xFFE6F1FA),
    surfaceVariant = Color(0xFF1B3A57),
    onSurfaceVariant = Color(0xFFA9C1D9),
    outline = Color(0xFF3B5B7A),
    error = Color(0xFFFF8A80)
)

@Composable
fun PecheTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Colors,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
