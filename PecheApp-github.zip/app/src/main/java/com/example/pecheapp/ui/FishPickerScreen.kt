package com.example.pecheapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val ALL_FISH = listOf(
    "Truite fario", "Truite arc-en-ciel", "Brochet", "Sandre", "Perche",
    "Black-bass", "Carpe", "Silure", "Gardon", "Barbeau", "Chevesne", "Saumon"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FishPickerScreen(initial: Set<String>, onDone: (Set<String>) -> Unit) {
    var chosen by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().background(OceanBrush).systemBarsPadding().padding(24.dp)) {
        Text("Tes poissons préférés", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(6.dp))
        Text(
            "On s'en sert pour te proposer les meilleurs spots autour de toi.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        FlowRow(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ALL_FISH.forEach { f ->
                val on = f in chosen
                FilterChip(
                    selected = on,
                    onClick = { chosen = if (on) chosen - f else chosen + f },
                    label = { Text(f, modifier = Modifier.padding(vertical = 8.dp)) },
                    leadingIcon = if (on) { { Icon(Icons.Filled.Check, null, Modifier.size(18.dp)) } } else null,
                    shape = MaterialTheme.shapes.medium
                )
            }
        }
        Button(
            onClick = { onDone(chosen) },
            enabled = chosen.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = MaterialTheme.shapes.medium
        ) { Text("Continuer (${chosen.size})", fontWeight = FontWeight.SemiBold) }
    }
}
