package com.example.pecheapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Tab(val label: String, val icon: ImageVector) {
    Accueil("Accueil", Icons.Filled.Home),
    Spots("Spots", Icons.Filled.Place),
    Regles("Règles", Icons.Filled.Gavel),
    Profil("Profil", Icons.Filled.Person)
}

@Composable
fun HomeScreen(username: String, fish: Set<String>, onEditFish: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.Accueil) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = NavyLight) {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t, onClick = { tab = t },
                        icon = { Icon(t.icon, null) }, label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().background(OceanBrush).padding(pad)) {
            when (tab) {
                Tab.Accueil -> AccueilTab(username, fish)
                Tab.Spots -> SpotsTab(fish)
                Tab.Regles -> ReglesTab()
                Tab.Profil -> ProfilTab(username, fish, onEditFish, onLogout)
            }
        }
    }
}

@Composable
private fun Title(text: String, sub: String? = null) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Text(text, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        sub?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, title: String, text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AccueilTab(username: String, fish: Set<String>) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Title("Bonjour, $username", "Prêt pour une belle sortie ?") }
        item { InfoCard(Icons.Filled.Cloud, "Météo du jour", "Branchement sur l'API météo : prochaine étape") }
        item { InfoCard(Icons.Filled.Waves, "Lâchers de poissons", "Calendrier des lâchers : prochaine étape") }
        item { Text("Pour tes poissons préférés", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground) }
        items(fish.toList()) { f -> InfoCard(Icons.Filled.Place, f, "Spots proches de toi via le GPS : bientôt") }
    }
}

@Composable
private fun SpotsTab(fish: Set<String>) {
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("Spots", "Autour de ta position")
        InfoCard(Icons.Filled.MyLocation, "Carte et GPS", "La carte des spots arrive à l'étape suivante")
        InfoCard(Icons.Filled.Tune, "Filtres", "Poissons suivis : ${fish.joinToString(", ")}")
    }
}

@Composable
private fun ReglesTab() {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Title("Réglementation", "Selon ton département") }
        item { InfoCard(Icons.Filled.Straighten, "Tailles légales", "Tailles minimales par espèce") }
        item { InfoCard(Icons.Filled.Rule, "Méthodes de pêche", "Techniques et appâts autorisés") }
        item { InfoCard(Icons.Filled.DirectionsBoat, "Navigation", "Bateau, float tube, engins autorisés") }
        item { InfoCard(Icons.Filled.Event, "Dates d'ouverture", "Ouverture et fermeture par espèce") }
    }
}

@Composable
private fun ProfilTab(username: String, fish: Set<String>, onEditFish: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title(username, "Compte pêcheur")
        InfoCard(Icons.Filled.Favorite, "Poissons préférés", fish.joinToString(", "))
        OutlinedButton(onClick = onEditFish, modifier = Modifier.fillMaxWidth().height(52.dp), shape = MaterialTheme.shapes.medium) {
            Text("Modifier mes poissons")
        }
        Button(
            onClick = onLogout, modifier = Modifier.fillMaxWidth().height(52.dp), shape = MaterialTheme.shapes.medium,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface)
        ) { Text("Se déconnecter") }
    }
}
