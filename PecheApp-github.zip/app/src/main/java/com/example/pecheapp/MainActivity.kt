package com.example.pecheapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pecheapp.data.AuthRepository
import com.example.pecheapp.ui.AuthScreen
import com.example.pecheapp.ui.FishPickerScreen
import com.example.pecheapp.ui.HomeScreen
import com.example.pecheapp.ui.PecheTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = AuthRepository(applicationContext)
        setContent { PecheTheme { PecheApp(repo) } }
    }
}

@Composable
fun PecheApp(repo: AuthRepository) {
    val nav: NavHostController = rememberNavController()
    val start = when {
        repo.currentUser == null -> "login"
        repo.favoriteFish().isEmpty() -> "fish"
        else -> "home"
    }
    NavHost(nav, startDestination = start) {
        composable("login") {
            AuthScreen(
                isRegister = false,
                onSubmit = { u, p -> repo.login(u, p) },
                onSwitch = { nav.navigate("register") },
                onSuccess = {
                    val next = if (repo.favoriteFish().isEmpty()) "fish" else "home"
                    nav.navigate(next) { popUpTo("login") { inclusive = true } }
                }
            )
        }
        composable("register") {
            AuthScreen(
                isRegister = true,
                onSubmit = { u, p -> repo.register(u, p) },
                onSwitch = { nav.popBackStack() },
                onSuccess = { nav.navigate("fish") { popUpTo("login") { inclusive = true } } }
            )
        }
        composable("fish") {
            FishPickerScreen(
                initial = repo.favoriteFish(),
                onDone = { chosen ->
                    repo.saveFavoriteFish(chosen)
                    nav.navigate("home") { popUpTo(nav.graph.id) { inclusive = true } }
                }
            )
        }
        composable("home") {
            HomeScreen(
                username = repo.currentUser ?: "",
                fish = repo.favoriteFish(),
                onEditFish = { nav.navigate("fish") },
                onLogout = {
                    repo.logout()
                    nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
                }
            )
        }
    }
}
